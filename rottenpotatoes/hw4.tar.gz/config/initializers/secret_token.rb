# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = 'e7079e345d62d1b4db2c5620dda16afc2b06de1e02080bbe40eef128c0559dc58c6c607862794d066eadec80af9e785249e1657836a7522c76f3e3bea8fcbd75'
